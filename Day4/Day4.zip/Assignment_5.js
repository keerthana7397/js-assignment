let sales=parseInt(prompt('Enter the amount of sales'));
/*if(sales<=5000)
{
    console.log(sales*0.02);
}
else if(sales>5000 && sales<=10000)
{
    console.log(sales*0.05);
}
else if(sales>10000 && sales<=20000)
{
    console.log(sales*0.07);
}
else
{
    console.log(sales*0.1);
}*/
let sum=0;
switch(true)
{
    case (sales>20000):
        sum=sum+((sales-20000)*0.1);
    case (sales>10000 && sales<=20000):
        if(sales>20000)
        sum=sum+700;
        else
        sum=sum+(sales-10000)*0.07;
    case (sales>5000 && sales<=10000):
        if(sales>=10000)
        sum=sum+250;
        else
        sum=sum+((sales-5000)*0.05);
    case (sales<=5000):
        if(sales<5000)
        sum=sum+(sales*0.02);
        else
        sum=sum+100;
}
console.log(sum);
let sales=parseInt(prompt('Enter the amount of sales'));
if(sales<=5000)
{
    console.log(sales*0.02);
}
else if(sales>5000 && sales<=10000)
{
    console.log(sales*0.05);
}
else if(sales>10000 && sales<=20000)
{
    console.log(sales*0.07);
}
else
{
    console.log(sales*0.1);
}
var shoppingList=['Sugar','Biscuit','Toothpaste','Noodles'];
var shoppingBasket=shoppingList.concat(['Oil','Tea Packet','Soap','Shampoo']);
console.log(shoppingBasket);
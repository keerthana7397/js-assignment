let n=parseInt(prompt("Enter a nummber greater than 1"));
console.log(2);
for(var i=3;i<=n;i=i+2)
{
    let a=Math.sqrt(i);
    let j=3,count=0;
    while(j<=a)
    {
        if(i%j==0)
        {
            count++;
            break;
        }
        j=j+2;
    }
    if(count==0)
    console.log(i);
}
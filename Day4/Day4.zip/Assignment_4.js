var num1=parseInt(prompt("Enter first numbers","0"));
var num2=parseInt(prompt("Enter second numbers","0"));
var ch=parseInt(prompt("Enter the operation mode 1:Addition 2:Subtraction 3:Multiplication 4:Division 5:Square root 6:Percentage",0));
switch(parseInt(ch))
{
    case 1: 
    console.log(num1+num2);
    break;
    case 2: console.log(num1-num2);
    break;
    case 3: console.log(num1*num2);
    break;
    case 4: console.log(num1/num2);
    break;
    case 5: console.log(Math.sqrt(num1));
    console.log(Math.sqrt(num2));
    break;
    case 6: console.log((num1/num2)*100);
    break;
    default: console.log('Enter a valid choice');
    break;
}
do
{
    var num=parseInt(prompt("Enter a number greater than 100"));
    if(isNaN(num) || num>100)
    break;
}while(1)
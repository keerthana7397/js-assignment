var user=prompt("Enter your name"); 
var age=prompt("Enter your age"); 
var birth=2020-age; 
console.log("Hi!"+user+"! Your birth year is:"+birth);
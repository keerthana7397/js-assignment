var age=confirm("Are you above 21 years of age?");
if (age)
{ 
    console.log("Can Drink");
}
else
{
    console.log("Cannot Drink");
}
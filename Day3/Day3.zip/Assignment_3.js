var mark=prompt("Enter the marks");

//If statement
if (mark>60)
{
    console.log(`Marks are ${mark} and grade is A`);
}
else if (mark<=60 && mark>=50) {
    console.log(`Marks are ${mark} and grade is B`);
} else {
    console.log(`Marks are ${mark} and grade is C`);
}

//Ternary operator
console.log((mark>60)?`Marks are ${mark} and grade is A`:(mark<=60 && mark>=50)?`Marks are ${mark} and grade is B`:`Marks are ${mark} and grade is C`);

//Switch statement
var res=(mark>60)?1:(mark<=60 && mark>=50)?2:3;
switch(res)
{
    case 1:
        console.log(`Marks are ${mark} and grade is A`);
        break;
    case 2:
        console.log(`Marks are ${mark} and grade is B`);
        break;
    default:
        console.log(`Marks are ${mark} and grade is C`);
}
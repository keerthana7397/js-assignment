var str=prompt("Enter the OS name and version");
var res=str.split(" ");
console.log(`The OS name is ${res[0]} and version is ${res[1]}.`);
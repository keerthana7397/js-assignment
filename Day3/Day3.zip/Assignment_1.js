var num=prompt("Enter the number");
function OddEven(x)
{
    if(x%2==0)
    {
        return "even";
    }
    else
    {
        return "odd";
    }
}
var res=OddEven(num);
console.log(`The number entered is ${num} and Number is ${res}`);